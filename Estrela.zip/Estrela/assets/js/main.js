// Variável para monitorar se um popup está aberto
let popupOpen = false;

// Funções para abrir e fechar o Popup 1
function openPopup() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true; // Indica que um popup está aberto
    togglePopup('popup', 'flex'); // Mostra o popup
}

function closePopup() {
    popupOpen = false; // Indica que o popup está fechado
    togglePopup('popup', 'none'); // Esconde o popup
}

// Funções para abrir e fechar o Popup 2
function openPopup2() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true;
    togglePopup('popup2', 'flex'); // Mostra o popup 2
}

function closePopup2() {
    popupOpen = false;
    togglePopup('popup2', 'none'); // Esconde o popup 2
}

// Funções para abrir e fechar o Popup 3
function openPopup3() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true;
    togglePopup('popup3', 'flex'); // Mostra o popup 3
}

function closePopup3() {
    popupOpen = false;
    togglePopup('popup3', 'none'); // Esconde o popup 3
}

// Função para alternar a exibição do popup
function togglePopup(popupId, displayStyle) {
    const popup = document.getElementById(popupId);
    popup.style.display = displayStyle; // Define a visibilidade do popup
    popup.setAttribute('aria-hidden', displayStyle === 'none' ? 'true' : 'false'); // Atualiza atributo de acessibilidade
}