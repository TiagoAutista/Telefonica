// Variável para monitorar se um popup está aberto
let popupOpen = false;

// Funções para abrir e fechar o Popup 1
function openPopup() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true; // Indica que um popup está aberto
    togglePopup('popup', 'flex'); // Mostra o popup
}

function closePopup() {
    popupOpen = false; // Indica que o popup está fechado
    togglePopup('popup', 'none'); // Esconde o popup
}

// Funções para abrir e fechar o Popup 2
function openPopup2() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true;
    togglePopup('popup2', 'flex'); // Mostra o popup 2
}

function closePopup2() {
    popupOpen = false;
    togglePopup('popup2', 'none'); // Esconde o popup 2
}

// Funções para abrir e fechar o Popup 3
function openPopup3() {
    if (popupOpen) return; // Impede abrir mais de um popup ao mesmo tempo
    popupOpen = true;
    togglePopup('popup3', 'flex'); // Mostra o popup 3
}

function closePopup3() {
    popupOpen = false;
    togglePopup('popup3', 'none'); // Esconde o popup 3
}

// Função para alternar a exibição do popup
function togglePopup(popupId, displayStyle) {
    const popup = document.getElementById(popupId);
    popup.style.display = displayStyle; // Define a visibilidade do popup
    popup.setAttribute('aria-hidden', displayStyle === 'none' ? 'true' : 'false'); // Atualiza atributo de acessibilidade
}



// Função para alternar a exibição do popup



const abasAbertas = [];

function abrirNovaAba(url) {
    if (!url) return;
    const novaAba = window.open(url, '_blank');
    if (novaAba) abasAbertas.push(novaAba);
}

function showSuperAttack() {
    const overlay = document.getElementById('superAttackOverlay');
    overlay.style.opacity = '1';
    overlay.style.pointerEvents = 'auto';
    setTimeout(() => {
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.style.pointerEvents = 'none';
        }, 300);
    }, 1200); // Duração do GIF visível: ~1.2s
}

function abrirAtendimentoNext() {
    const pon = document.getElementById('filter-pon-next').value.trim();
    if (!pon) return alert('Por favor, insira o Pon.');
    showSuperAttack();
    setTimeout(() => abrirNovaAba(`http://gps.redecorp.br/gps/atendimento/index.jsf?documento=${encodeURIComponent(pon)}`), 1300);
    document.getElementById('filter-pon-next').value = '';
}

function abrirAtendimentoSiebel() {
    const code = document.getElementById('filter-pon-siebel').value.trim();
    if (!pon) return alert('Por favor, insira o Pon.');
    showSuperAttack();
    setTimeout(() => abrirNovaAba(`http://gpscrm.gvt.com.br/gps/crm/atendimento/index.jsf?documento=${encodeURIComponent(pon)}`), 1300);
    document.getElementById('filter-pon-next').value = '';
}

function abrirAtendimentoWFM() {
    const code = document.getElementById('filter-pon-WFM').value.trim();
    if (!pon) return alert('Por favor, insira o Pon.');
    showSuperAttack();
    setTimeout(() => abrirNovaAba(`http://appwfm.gvt.net.br/wfm-search/detalhesWorkOrder.xhtml?wo=${encodeURIComponent(pon)}`), 1300);
    document.getElementById('filter-pon-next').value = '';
}

function fecharLinks() {
    abasAbertas.forEach(aba => {
        try {
            if (!aba.closed) aba.close();
        } catch (e) {
            console.warn('Não foi possível fechar uma aba:', e);
        }
    });
    abasAbertas.length = 0; // limpa o array
}

// Função de geração de descrição
document.getElementById('generateButton')?.addEventListener('click', () => {
    const input = document.getElementById('inputDados');
    const output = document.getElementById('resultado');

    if (!input || !output) return;

    const dataString = input.value.trim();
    if (!dataString) {
        output.innerHTML = '<p style="color: red;">Por favor, cole os dados!</p>';
        return;
    }

    const descricao = gerarDescricao(dataString);
    output.innerHTML = `<pre>${descricao}</pre>`;
});

function gerarDescricao(dataString) {
    const regexMap = {
        dataTabulacao: /Data Tabulação:\s*([^]*?)(?=\s*RE Colaborador:)/,
        colaboradorResponsavel: /Colaborador Responsável:\s*([^]*?)(?=\s*Ordem de Serviço:)/,
        ordemServico: /Ordem de Serviço:\s*([^]*?)(?=\s*Status Rota:)/,
        timeSlot: /Time Slot:\s*([^]*?)(?=\s*Servico:)/,
        servico: /Servico:\s*([^]*?)(?=\s*Nome do técnico:)/,
        nomeTecnico: /Nome do técnico:\s*([^]*?)(?=\s*Contato técnico:)/,
        tecnologia: /Tecnologia:\s*([^]*?)(?=\s*Cluster:)/,
        statusTratativa: /Status Tratativa:\s*([^]*?)(?=\s*Houve Contato com o Cliente:)/
    };

    const dados = {};
    for (const [key, regex] of Object.entries(regexMap)) {
        const match = dataString.match(regex);
        dados[key] = match ? match[1].trim() : 'não informado';
    }

    const dataFormatada = formatarData(dados.dataTabulacao);
    const servicoFormatado = formataServico(dados.servico);

    return `
Descrição do Chamado Técnico:

No dia ${dataFormatada || 'data não informada'}, foi realizada a tabulação do chamado. O colaborador responsável por esse atendimento foi ${dados.colaboradorResponsavel}. O número da ordem de serviço é ${dados.ordemServico}, programada para um intervalo de execução de ${dados.timeSlot}. O serviço solicitado foi ${servicoFormatado || dados.servico}, e o técnico designado para a tarefa foi ${dados.nomeTecnico}. A tecnologia utilizada é ${dados.tecnologia}. O status da tratativa do chamado é: ${dados.statusTratativa}.

A equipe deve acompanhar o andamento desta solicitação e garantir que as ações necessárias sejam realizadas de forma eficaz.
      `.trim();
}

function formatarData(dataStr) {
    if (!dataStr) return null;
    const match = dataStr.match(/\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/);
    if (!match) return null;
    const data = new Date(match[0]);
    return data.toLocaleDateString('pt-BR', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false
    }).replace(' às ', ' às ');
}

function formataServico(servicoStr) {
    if (!servicoStr || !servicoStr.includes('||')) return null;
    return servicoStr
        .split('||')
        .map(part => part.split('-')[1]?.trim())
        .filter(Boolean)
        .join(' / ');
}

// Função para alternar a exibição do popup

// Simula verificação de sistemas (em produção, você faria requisições reais)
function checkSystemStatus() {
  const systems = {
    'outlook': 'https://outlook.office.com/mail/',
    'successfactors': 'https://performancemanager5.successfactors.eu/sf/home',
    'nice': 'https://vivowfm.redecorp.br/wfm/login?logout=true',
    'vivopessoas': 'https://rhtelefonica.zendesk.com/hc/pt-br',
    'intranet': 'https://intranet.telefonica.com.br/noticias'
  };

  // Como não podemos fazer requisições cross-origin facilmente, vamos simular:
  // Em ambiente real, você usaria um backend ou proxy para testar conectividade.
  Object.keys(systems).forEach(key => {
    const el = document.getElementById(`status-${key}`);
    if (el) {
      // Simulação: 80% de chance de estar online
      const isOnline = Math.random() > 0.2;
      el.className = `system-item ${isOnline ? 'online' : 'offline'}`;
      el.textContent = isOnline ? el.textContent : `${el.textContent} ✘`;
    }
  });
}

// Executa ao carregar a página
window.addEventListener('load', checkSystemStatus);

function mudarTema(tema) {
  const root = document.documentElement;
  root.className = ''; // remove temas anteriores

  if (tema === 'dark') {
    root.classList.add('dark-theme');
    localStorage.setItem('tema-kof', 'dark');
  } else if (tema === 'red') {
    root.classList.add('red-theme');
    localStorage.setItem('tema-kof', 'red');
  } else {
    // tema padrão
    localStorage.setItem('tema-kof', 'default');
  }
}

// Aplicar tema salvo ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
  const temaSalvo = localStorage.getItem('tema-kof');
  if (temaSalvo) {
    mudarTema(temaSalvo);
  }
});
